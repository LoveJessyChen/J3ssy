<center>
  <a href="#"><img src="https://i.imgur.com/WlcHi3M.png" alt="Logo" width="40%"></a>
</center>

Project for the c0met jailbreak. 
This jailbreak is an open source project.

### Supported devices:

All iOS devices from 14.0 - 14.3

### Status:

Exploit: Working <br />
Privilege Escalation: Working <br />

### License: 
GNU GENERAL PUBLIC LICENSE <br />
Version 3, 29 June 2007 <br />

 Copyright (C) 2007 Free Software Foundation, Inc. <https://fsf.org/> <br />
 Everyone is permitted to copy and distribute verbatim copies <br />
 of this license document, but changing it is not allowed. <br />

# Special Thanks to
@Maverickdev1 - Utility development<br />
@ModernPwner - CVE (cicuta_virosa)<br />
@Brandonplank - Sandbox r/w priviliges <br />

Join us -> https://discord.gg/ey6FAabR46

