#pragma once
#include <stdint.h>

void increase_limits(uint32_t limit);
