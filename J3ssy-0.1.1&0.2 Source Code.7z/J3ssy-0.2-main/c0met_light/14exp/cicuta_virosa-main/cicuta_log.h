#pragma once
#include <stdio.h>

void cicuta_log(const char* format, ...) __printflike(1, 2);
