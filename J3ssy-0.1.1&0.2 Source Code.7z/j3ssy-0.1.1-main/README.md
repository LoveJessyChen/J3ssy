# c0met14


This jailbreak is by the community, and was developed open source.

### Currently implemented: 
setuid(0); <br />
setgid(0); <br />
granted .root<br />
sandbox custom r/w perms.<br />
posix_spawn ret 0
amfid_slot patch

#### Output <br />
amfid_slot - > 16549200728742792240Cannot spray rthdr at 0. Error: 9 <br />
Cannot spray rthdr at 0. Error: 9 <br />

amfid_slot - > 16549200728742792240prison break :slight_smile: <br />
... <br />

# Special Thanks to
@maverickdev1 - utility development<br />
@ModernPwner - CVE (cicuta_virosa)<br />
@brandonplank - sandbox r/w priviliges


join us -> https://discord.gg/ey6FAabR46

